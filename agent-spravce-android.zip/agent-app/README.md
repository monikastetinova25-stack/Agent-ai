# Agent Správce — Android app (zdrojový kód)

Minimalistická nativní Android appka, která:

1. **Sleduje zvolenou složku** (`/Agent/` na úložišti telefonu) přes `FileObserver`.
2. Když se objeví nebo změní soubor, **nejdřív ho zkopíruje** do `/Agent/zaloha/` s časovým razítkem (originál se nikdy nepřepisuje).
3. Podle obsahu pozná typ (kniha / reklama / obecný text) a pošle ho na Claude API.
4. Odpověď uloží jako novou verzi souboru (`nazev_v2.txt`).
5. `SmsReceiver` zachytává příchozí SMS, pošle je na Claude API a **automaticky odešle odpověď zpět** — bez potvrzování.

## Než začneš — přečti si tohle

- **Musíš appku sám sestavit.** Stáhni si zdrojáky, otevři v Android Studiu, sestav a nainstaluj na telefon. Nikdo (ani Anthropic) ti appku nemůže nainstalovat za tebe ani na dálku.
- **Automatické čtení a odesílání SMS je na Androidu silně omezené.** Google od appek mimo roli "výchozí SMS aplikace" běžně nepovoluje `RECEIVE_SMS` + `SEND_SMS` bez placeného Play Console review a jasného účelu. Appka nahraná na Play Store s touto funkcí bude pravděpodobně zamítnuta nebo bude vyžadovat, aby se stala výchozí SMS appkou telefonu. Pro osobní použití (sestavení a instalace přes Android Studio na vlastní telefon, tzv. "sideload") to funguje bez Play Store schválení.
- **API klíč v appce = riziko.** Kód níže má klíč jen jako demonstraci v `local.properties` — nikdy ho nenahrávej na veřejný GitHub repozitář. Pro cokoliv reálného patří API klíč na tvůj vlastní backend server, ne přímo do appky.
- **Appka posílá zprávy bez tvé kontroly.** To je přesně to, o co jsi žádal, ale reálně to znamená, že chybný draft půjde ven nikým nezkontrolovaný. Doporučuju nechat zapnutý `LOG_ONLY` režim (viz `Config.kt`) při prvních testech — loguje, co by se odeslalo, ale neodesílá to.
- Real-life nasazení (baterie, Android background limity, Doze mode) bude vyžadovat doladění — `FileObserver` a `BroadcastReceiver` na moderním Androidu občas usínají, pokud appku nevyjmeš z optimalizace baterie.

## Nahrání na GitHub

```bash
cd agent-app
git init
echo "local.properties" >> .gitignore
echo "*.apk" >> .gitignore
git add .
git commit -m "Initial commit: Agent Správce Android app"
git branch -M main
git remote add origin https://github.com/TVOJE_JMENO/agent-spravce.git
git push -u origin main
```

## Sestavení

1. Otevři složku `agent-app/` v Android Studiu.
2. Do `local.properties` přidej: `CLAUDE_API_KEY=sk-ant-...` (klíč z [console.anthropic.com](https://console.anthropic.com))
3. Připoj telefon (USB debugging zapnutý) → Run.
4. Appka si při prvním spuštění vyžádá oprávnění: úložiště, SMS.
5. V nastavení telefonu appku vyjmi z optimalizace baterie, ať `FileObserver` neusíná.

## Struktura

```
app/src/main/java/com/agent/spravce/
├── MainActivity.kt        — UI, žádost o oprávnění, start/stop služby
├── FileWatcherService.kt  — foreground služba, sleduje složku, volá API
├── SmsReceiver.kt         — zachytává SMS, volá API, odesílá odpověď
├── ClaudeApiClient.kt     — HTTP volání na Anthropic API
└── Config.kt              — přepínač LOG_ONLY / REAL_SEND
```

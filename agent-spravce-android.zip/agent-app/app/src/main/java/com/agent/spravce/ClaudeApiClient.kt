package com.agent.spravce

import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object ClaudeApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"

    /** Synchronní volání — volej z pozadí (service/receiver), ne z hlavního vlákna. */
    fun ask(prompt: String): String {
        val body = JSONObject().apply {
            put("model", Config.CLAUDE_MODEL)
            put("max_tokens", 1000)
            put("messages", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                }
            ))
        }

        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("x-api-key", BuildConfig.CLAUDE_API_KEY)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(RequestBody.create(
                MediaType.parse("application/json"), body.toString()
            ))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Claude API chyba: ${response.code} ${response.body?.string()}")
            }
            val json = JSONObject(response.body!!.string())
            val content = json.getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") {
                    sb.append(block.optString("text"))
                }
            }
            return sb.toString().trim()
        }
    }
}

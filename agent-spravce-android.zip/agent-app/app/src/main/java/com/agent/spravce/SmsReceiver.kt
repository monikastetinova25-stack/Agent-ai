package com.agent.spravce

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsManager
import android.util.Log
import kotlin.concurrent.thread

/**
 * Zachytává příchozí SMS a automaticky navrhne / odešle odpověď přes Claude API.
 *
 * POZOR: Google Play od 2022 silně omezuje appky mimo roli výchozí SMS aplikace
 * v přístupu k RECEIVE_SMS/SEND_SMS pro automatizaci. Toto funguje při sideloadu
 * (instalace mimo Play Store, přes Android Studio) na vlastní telefon, ale
 * nasazení na Play Store by vyžadovalo appku jako výchozí SMS klienta.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        for (sms in messages) {
            val from = sms.originatingAddress ?: continue
            val body = sms.messageBody ?: continue

            thread {
                try {
                    val prompt = "Toto je přijatá SMS. Navrhni krátkou, přirozenou odpověď v " +
                            "češtině, zdvořilou a věcnou. Vrať pouze text odpovědi.\n\nZpráva:\n$body"
                    val reply = ClaudeApiClient.ask(prompt)

                    if (Config.LOG_ONLY) {
                        Log.i("AgentSpravce", "LOG_ONLY: NEODESLÁNO komu=$from text=$reply")
                    } else {
                        val smsManager = SmsManager.getDefault()
                        smsManager.sendTextMessage(from, null, reply, null, null)
                        Log.i("AgentSpravce", "DONE: odpověď odeslána → $from")
                    }
                } catch (e: Exception) {
                    Log.e("AgentSpravce", "Chyba při odpovídání na SMS od $from", e)
                }
            }
        }
    }
}

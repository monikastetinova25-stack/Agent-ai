package com.agent.spravce

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.FileObserver
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

class FileWatcherService : Service() {

    private var observer: FileObserver? = null
    private val watchDir by lazy {
        File(Environment.getExternalStorageDirectory(), Config.WATCH_FOLDER).apply { mkdirs() }
    }
    private val backupDir by lazy {
        File(watchDir, Config.BACKUP_SUBFOLDER).apply { mkdirs() }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification("Agent sleduje složku ${watchDir.path}"))
        startWatching()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        observer?.stopWatching()
        super.onDestroy()
    }

    private fun startWatching() {
        @Suppress("DEPRECATION")
        observer = object : FileObserver(watchDir.path, CLOSE_WRITE or MOVED_TO) {
            override fun onEvent(event: Int, path: String?) {
                if (path == null) return
                if (path.startsWith(Config.BACKUP_SUBFOLDER)) return // neřeš vlastní zálohy
                val file = File(watchDir, path)
                if (file.isFile) {
                    thread { handleFile(file) }
                }
            }
        }
        observer?.startWatching()
    }

    private fun handleFile(file: File) {
        try {
            val content = file.readText()
            if (content.isBlank()) return

            // 1) ZÁLOHA — originál se nikdy nepřepisuje
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val backupFile = File(backupDir, "${file.nameWithoutExtension}_${stamp}${file.extension.let { if (it.isNotEmpty()) ".$it" else "" }}")
            file.copyTo(backupFile, overwrite = false)
            log("COPY: záloha uložena → ${backupFile.name}")

            // 2) KLASIFIKACE
            val type = classify(file.name, content)
            log("READ: ${file.name} rozpoznán jako '$type'")

            // 3) DRAFT přes Claude API
            val prompt = buildPrompt(type, content)
            val draft = ClaudeApiClient.ask(prompt)

            // 4) ULOŽENÍ NOVÉ VERZE (originál beze změny)
            val newVersionName = "${file.nameWithoutExtension}_v2${if (file.extension.isNotEmpty()) ".${file.extension}" else ""}"
            val newVersionFile = File(watchDir, newVersionName)

            if (Config.LOG_ONLY) {
                log("LOG_ONLY: NEZAPSÁNO — byl by vytvořen ${newVersionFile.name} s ${draft.length} znaky")
            } else {
                newVersionFile.writeText(draft)
                log("DONE: nová verze zapsána → ${newVersionFile.name}")
            }

        } catch (e: Exception) {
            Log.e("FileWatcherService", "Chyba při zpracování ${file.name}", e)
        }
    }

    private fun classify(name: String, content: String): String {
        val c = (name + content).lowercase()
        return when {
            "kapitol" in c || "kniha" in c || "román" in c -> "kniha"
            "reklam" in c || "inzerát" in c -> "reklama"
            else -> "obecny"
        }
    }

    private fun buildPrompt(type: String, content: String): String = when (type) {
        "kniha" -> "Toto je rozpracovaný text z knihy. Napiš plynulé pokračování v češtině, cca 150-200 slov, navazující stylem a dějem. Vrať pouze text pokračování.\n\n$content"
        "reklama" -> "Na základě tohoto zadání napiš hotový reklamní text v češtině (2 varianty) a stručná doporučení pro cílení a metriky.\n\n$content"
        else -> "Zpracuj následující text a vrať vylepšenou/doplněnou verzi v češtině.\n\n$content"
    }

    private fun log(msg: String) {
        Log.i("AgentSpravce", msg)
        // Volitelně: zapisuj i do logovacího souboru pro transparentnost
        try {
            val logFile = File(watchDir, "agent_log.txt")
            logFile.appendText("${Date()} — $msg\n")
        } catch (_: Exception) {}
    }

    private fun buildNotification(text: String): Notification {
        val channelId = "agent_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Agent Správce", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Agent Správce běží")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true)
            .build()
    }
}

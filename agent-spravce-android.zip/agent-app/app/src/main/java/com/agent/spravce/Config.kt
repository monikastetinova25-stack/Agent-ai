package com.agent.spravce

object Config {
    /**
     * Dokud je true, appka jen LOGUJE, co by odeslala / přepsala,
     * ale skutečně nic neodešle ani nezapíše mimo /zaloha/.
     * Nastav na false, až si budeš jistý chováním agenta.
     */
    const val LOG_ONLY = true

    /** Složka na úložišti, kterou agent sleduje. */
    const val WATCH_FOLDER = "Agent"

    /** Podsložka pro automatické zálohy originálů. */
    const val BACKUP_SUBFOLDER = "zaloha"

    const val CLAUDE_MODEL = "claude-sonnet-4-6"
}

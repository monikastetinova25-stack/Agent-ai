package com.agent.spravce

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val permissions = mutableListOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_SMS
    ).apply {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            add(Manifest.permission.READ_EXTERNAL_STORAGE)
            add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.statusText).text =
            "Složka: ${Environment.getExternalStorageDirectory()}/${Config.WATCH_FOLDER}\n" +
            "Režim: ${if (Config.LOG_ONLY) "LOG_ONLY (nic se reálně neodesílá/nepřepisuje)" else "REAL_SEND (ostrý provoz)"}"

        findViewById<Button>(R.id.btnGrant).setOnClickListener { requestAllPermissions() }
        findViewById<Button>(R.id.btnStart).setOnClickListener { startAgent() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { stopAgent() }
        findViewById<Button>(R.id.btnBattery).setOnClickListener { requestIgnoreBatteryOptimization() }
    }

    private fun requestAllPermissions() {
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        } else {
            Toast.makeText(this, "Všechna oprávnění už jsou udělena", Toast.LENGTH_SHORT).show()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        }
    }

    private fun requestIgnoreBatteryOptimization() {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        intent.data = Uri.parse("package:$packageName")
        startActivity(intent)
    }

    private fun startAgent() {
        ContextCompat.startForegroundService(this, Intent(this, FileWatcherService::class.java))
        Toast.makeText(this, "Agent spuštěn — běží na pozadí", Toast.LENGTH_SHORT).show()
    }

    private fun stopAgent() {
        stopService(Intent(this, FileWatcherService::class.java))
        Toast.makeText(this, "Agent zastaven", Toast.LENGTH_SHORT).show()
    }
}
